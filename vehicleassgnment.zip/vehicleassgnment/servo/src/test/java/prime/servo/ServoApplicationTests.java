package prime.servo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServoApplicationTests {

	@Test
	void contextLoads() {
	}

}
