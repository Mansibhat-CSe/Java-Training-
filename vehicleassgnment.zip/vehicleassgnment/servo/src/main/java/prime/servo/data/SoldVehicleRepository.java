package prime.servo.data;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SoldVehicleRepository extends JpaRepository<SoldVehicle, Integer> {

}
