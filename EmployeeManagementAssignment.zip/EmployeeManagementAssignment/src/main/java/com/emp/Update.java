package com.emp;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Update
 */
@WebServlet("/Update")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		int salary=Integer.parseInt(request.getParameter("salary"));
		boolean current_user=Boolean.parseBoolean(request.getParameter("current_user"));
		request.getSession().setAttribute("email", email);
		String sql="update emp2 set name=?, email=?, password=?, salary=? where id=?";
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","B@131149");PreparedStatement ps=con.prepareStatement(sql)) {
			ps.setInt(5, id);
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, password);
			ps.setInt(4, salary);
			int update=ps.executeUpdate();
			if(update>0) {
				if(current_user) {
					EmpDetails oldEmp=(EmpDetails) request.getSession().getAttribute("emp");
					EmpDetails e=new EmpDetails(id,name,email,password,salary,oldEmp.getPermission());
					request.getSession().setAttribute("emp",e);
				}
				Login.getAllEmp(request, con);
				request.getSession().setAttribute("message", "user Updated SuccessFull");	
				RequestDispatcher rd=request.getRequestDispatcher("/Home.jsp");
				rd.forward(request, response);
				return;
			}
			else {
				request.getSession().setAttribute("error", "Something Wrong in Register");
				RequestDispatcher rd=request.getRequestDispatcher("/Home.jsp");
				rd.forward(request, response);
				return;
			}
			
		}
		catch(Exception e) {
			System.out.println("execption  : "+e);
			request.getSession().setAttribute("error", e.getMessage());
			RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
			rd.forward(request, response);
			return;
		}
	}

}
